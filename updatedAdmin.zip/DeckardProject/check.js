
function check(form) {
 if(form.username.value == "admin" && form.password.value == "password")
	{
		window.open("adminhomepage.html")
		}
		else
		{
			alert("Incorrect Username or Password.  Try again")
			}
}
	
			